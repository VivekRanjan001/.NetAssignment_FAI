﻿namespace E2EWebApiHackathon.Models
{
    public class Hotel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        // Add other properties as needed
    }
}
