﻿namespace E2EWebApiHackathon.Models
{
    public class MenuItem
    {
        //make same as hotel.cs id name and discription price
    }
}
